package Missoes;

import Interfaces.ModoAutomaticoADT;

public class ModoAutomatico extends ModosJogo implements ModoAutomaticoADT {

    @Override
    public void modoAutmomatico() {

    }
}
