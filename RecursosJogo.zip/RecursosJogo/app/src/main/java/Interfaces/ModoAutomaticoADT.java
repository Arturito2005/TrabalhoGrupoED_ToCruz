package Interfaces;

public interface ModoAutomaticoADT {
    public void modoAutmomatico();
}
