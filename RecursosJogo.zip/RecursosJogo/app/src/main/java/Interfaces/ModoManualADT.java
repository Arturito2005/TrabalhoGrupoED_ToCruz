package Interfaces;

public interface ModoManualADT {

    public void modoManual();
}
