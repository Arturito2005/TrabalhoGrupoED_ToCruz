package Exportar;

import Interfaces.Exportar;

/*
*
* @author Xico
* */
public class ExportarDado implements Exportar {


    @Override
    public void exportarDados(String path) {

    }
}
