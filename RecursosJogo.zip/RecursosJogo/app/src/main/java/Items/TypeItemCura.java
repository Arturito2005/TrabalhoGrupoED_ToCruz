package Items;

/**
 * Enum que aramzena todos os tipos de itens de cura
 * */
public enum TypeItemCura {
    KIT_VIDA, /**Representa o tipo de item kit de vida*/
    COLETE /**Representa o Tipo de item colete*/
}
